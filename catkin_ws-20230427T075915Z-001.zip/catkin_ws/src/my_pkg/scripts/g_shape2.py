#!/usr/bin/env python
import cv2 as cv
#Video translate
caption =cv.VideoCapture(0)
while True:
    isTrue, frame=caption.read()
    if isTrue:
 #       T_frame=translate(frame,100,100)
        cv.imshow('video',frame)
        #cv.imshow('T_video',T_frame)
        if cv.waitKey(20) & 0xFF==ord('d'):
            break
    else:
        break

caption.release()
cv.destroyAllWindows()